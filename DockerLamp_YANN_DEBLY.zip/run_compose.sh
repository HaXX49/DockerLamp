#!/bin/sh
# Pile LAMP - Docker Compose
# Yann Debly 2020

echo "Starting services ..."
docker-compose up --env-file ./config/.env -d --build