<h1>Le test de co à la DB !</h1>
<h4>Attempting MySQL connection from php...</h4>
<?php 
$host = 'mariadb';
$user = 'root';
$pass = 'N3tw0rk!';
$conn = new mysqli($host, $user, $pass);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected to MySQL successfully!";
?>